<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1">
    <title>Exam Login Page</title>
    <link rel="stylesheet" href="{{ asset('authentication_assets/style.css') }}">
    <link rel="shortcut icon" href="{{ asset('authentication_assets/images/Login_37128.ico') }}" />
    <!-- jquery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.min.js" integrity="sha512-AFwxAkWdvxRd9qhYYp1qbeRZj6/iTNmJ2GFwcxsMOzwwTaRwz2a/2TX225Ebcj3whXte1WGQb38cXE5j7ZQw3g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>	
</head>
<body>
    <div class="container">
        <div class="left">
            <h1>Welcome back!</h1>
            <p>This is a test login form, for <span style="color: #fc4f38;">Red Core Solutions</span></p>
        </div>
        <div class="right">
            <form action="{{ route('login') }}" method="POST">
                @csrf
                <input type="text" name="email" placeholder="Email addess"  value="{{ old('email') }}">
                <span class="validation_messages">
                    @error('email')*{{ $message }}@enderror
                </span>
                <input type="password" name="password" placeholder="Password">
                <span class="validation_messages">
                    @error('password')*{{ $message }}@enderror
                </span>
                <button type="submit" class="loginBtn">Log In</button>
                <!-- <a href="" class="forget">Forgotten password?</a> -->
                <div class="sign-up">
                    <a href="{{ route('show_register') }}" class="signupBtn">Create New Account</a>
                </div>
            </form>
        </div>
    </div>

    <!-- loader -->
    <div class="loader-wrapper">
        <span class="loader"><span class="loader-inner"></span></span>
    </div>

    <!-- script for loading -->
    <script>
        $(window).on("load",function(){
            $(".loader-wrapper").fadeOut("slow");
        });
    </script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js" integrity="sha512-AA1Bzp5Q0K1KanKKmvN/4d3IRKVlv9PYgwFPvm32nPO6QS8yH1HO7LbgB1pgiOxPtfeg5zEn2ba64MUcqJx6CA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
    @if (session('status'))
    swal({
        title: '{{ session('status') }}',
        icon: '{{ session('statuscode') }}',
        className: "sweet_alert",
    });
    @endif
    </script>
</body>
</html>