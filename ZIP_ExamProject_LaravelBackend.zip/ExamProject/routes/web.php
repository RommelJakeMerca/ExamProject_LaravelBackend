<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MainController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


// to register the user
Route::post('/auth/save', [MainController::class, 'register'])->name('register');
// to login the user
Route::post('/auth/login', [MainController::class, 'login'])->name('login');
// to logout user
Route::get('/auth/logout', [MainController::class, 'logout'])->name('logout');


// group route
Route::group(['middleware' => ['AuthCheck']], function(){
    // to show login view
    Route::get('/auth/login', [MainController::class, 'show_login'])->name('show_login');
    // to show register view
    Route::get('/auth/register', [MainController::class, 'show_register'])->name('show_register');

    // to show users dashboard
    Route::get('/users/dashboard', [MainController::class, 'show_dashboard'])->name('users_dashboard');
    // delete user from table
    Route::delete('/delete_user/{id}', [MainController::class, 'delete_user'])->name('delete_user');
    // show user details
    Route::get('/user_details/{id}', [MainController::class, 'user_details'])->name('user_details');
    // update user role
    Route::put('/update_user_role/{id}', [MainController::class, 'update_user_role'])->name('update_user_role');

    // to show users profile
    Route::get('/users_profile/user_profile', [MainController::class, 'show_userprofile'])->name('user_profile');
    // update user image
    Route::put('/update_userimage/{id}', [MainController::class, 'update_userimage'])->name('update_userimage');
    // update user details
    Route::put('/update_userdetails/{id}', [MainController::class, 'update_userdetails'])->name('update_userdetails');

    // to show roles table
    Route::get('/roles/roles', [MainController::class, 'show_roles'])->name('show_roles');
    // add roles to table
    Route::post('/add_role', [MainController::class, 'add_role'])->name('add_role');
    // delete role from table
    Route::delete('/delete_role/{id}',  [MainController::class, 'delete_role'])->name('delete_role');
    // show role update 
    Route::get('/role_update/{id}', [MainController::class, 'role_update'])->name('role_update');
    // update role from table
    Route::put('/role_update_action/{id}', [MainController::class, 'role_update_action'])->name('role_update_action');
});