
<?php $__env->startSection('title'); ?>
    LS | Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Topbar -->
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
        <!-- Sidebar Toggle (Topbar) -->
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>
        <!-- Topbar Navbar -->
        <ul class="navbar-nav ml-auto">
            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
                <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-search fa-fw"></i>
                </a>
                <!-- Dropdown - Messages -->
                <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                    aria-labelledby="searchDropdown">
                    <form class="form-inline mr-auto w-100 navbar-search">
                        <div class="input-group">
                            <input type="text" class="form-control bg-light border-0 small"
                                placeholder="Search for..." aria-label="Search"
                                aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="button">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </li>
            <div class="topbar-divider d-none d-sm-block"></div>
            <li class="nav-item dropdown no-arrow">
                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo e($LoggedUserInfo['fullname']); ?> </span>
                    <img class="img-profile rounded-circle"
                        src="/user_images/<?php echo e($LoggedUserInfo['user_image']); ?>">
                </a>
                <!-- Dropdown - User Information -->
                <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                    aria-labelledby="userDropdown">
                    <a class="dropdown-item" href="/users_profile/user_profile">
                        <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                        Profile
                    </a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                        <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                        Logout
                    </a>
                </div>
            </li>
        </ul>
    </nav>
<!-- End of Topbar -->


<!-- Modal For confirm delete -->
<div class="modal fade" id="deleteModalPop" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Confirm Delete</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <form id="deleteModalForm" method="POST">
          <?php echo e(csrf_field()); ?>

          <?php echo e(method_field('DELETE')); ?>

        <div class="modal-body">
          <div class="form-group">
            <h5>Are you sure you want to delete this user?</h5>
            <input type="hidden" name="id" class="form-control" id="delete_user_id" disabled>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary">Confirm Delete</button>
        </div>
        </form>

      </div>
    </div>
  </div>

<div class="container-fluid">
<div class="row">
    <div class="col-md-12">
      <div class="card card-tasks">
        <div class="card-header ">
          <h5 class="card-category">Users List</h5>
        </div>
        <div class="card-body ">
          <div class="table-full-width table-responsive">
              <style>
                a.disabled {
                    pointer-events: none;
                    cursor: default;
                }
              </style>
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Role ID</th>
                        <th>Role</th>
                        <th>Description</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text"><?php echo e($row->id); ?></td>
                            <td class="text"><?php echo e($row->fullname); ?></td>
                            <td class="text-left"><?php echo e($row->role_id); ?></td>
                            <?php $__currentLoopData = $roles->where('id', $row->role_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="text-left"><?php echo e($role->role_name); ?></td>
                                <td class="text-left"><?php echo e($role->role_description); ?></td>
                                <?php if($LoggedUserInfo['id'] == $row->id): ?>
                                    <td><a href="/province_update/" class="btn btn-warning disabled">Details</a></td>
                                    <td><a href="javascript:void(0)" class="btn btn-danger deletbtn disabled">Delete</a></td>
                                <?php else: ?>
                                    <?php if($LoggedUserInfo['role_id'] != 1000): ?>
                                        <td><a href="/province_update/" class="btn btn-info disabled">Details</a></td>
                                        <td><a href="javascript:void(0)" class="btn btn-danger deletbtn disabled">Delete</a></td>
                                    <?php else: ?>
                                        <td><a href="/user_details/<?php echo e($row->id); ?>" class="btn btn-info">Details</a></td>
                                        <td><a href="javascript:void(0)" class="btn btn-danger deletbtn">Delete</a></td>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>     

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('dashboard_assets/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
    $('#dataTable').DataTable();
    $('#dataTable').on('click', '.deletbtn', function() {
        $tr = $(this).closest('tr');

        var data = $tr.children("td").map(function() {
            return $(this).text();
        }).get(); 

        // console.log(data);

        $('#delete_user_id').val(data[0]);
        $('#deleteModalForm').attr('action', '/delete_user/'+data[0]);
        $('#deleteModalPop').modal('show');
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ExamProject\resources\views/users/dashboard.blade.php ENDPATH**/ ?>