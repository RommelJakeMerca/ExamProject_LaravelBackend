
<?php $__env->startSection('title'); ?>
    LS | User Profile
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
    <link href="<?php echo e(asset('dashboard_assets/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="<?php echo e(asset('dashboard_assets/css/sb-admin-2.min.css')); ?>" rel="stylesheet">
    
    <link href="<?php echo e(asset('dashboard_assets/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('landing_asset/css/style.css')); ?>">
    <!--========== CSS ==========-->
    <link rel="stylesheet" href="<?php echo e(asset('shop_index_assets/css/styles.css')); ?>">
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <!-- jquery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.min.js" integrity="sha512-AFwxAkWdvxRd9qhYYp1qbeRZj6/iTNmJ2GFwcxsMOzwwTaRwz2a/2TX225Ebcj3whXte1WGQb38cXE5j7ZQw3g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>	

<!-- Topbar -->
<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
    <!-- Sidebar Toggle (Topbar) -->
    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
        <i class="fa fa-bars"></i>
    </button>
    <!-- Topbar Navbar -->
    <ul class="navbar-nav ml-auto">
        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
        <li class="nav-item dropdown no-arrow d-sm-none">
            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
            </a>
            <!-- Dropdown - Messages -->
            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                    <div class="input-group">
                        <input type="text" class="form-control bg-light border-0 small"
                            placeholder="Search for..." aria-label="Search"
                            aria-describedby="basic-addon2">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="button">
                                <i class="fas fa-search fa-sm"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </li>
        <div class="topbar-divider d-none d-sm-block"></div>
        <li class="nav-item dropdown no-arrow">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo e($LoggedUserInfo['fullname']); ?> </span>
                <img class="img-profile rounded-circle"
                    src="/user_images/<?php echo e($LoggedUserInfo['user_image']); ?>">
            </a>
            <!-- Dropdown - User Information -->
            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                aria-labelledby="userDropdown">
                <a class="dropdown-item" href="/users_profile/user_profile">
                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                    Profile
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                    Logout
                </a>
            </div>
        </li>
    </ul>
</nav>
<!-- End of Topbar -->

<!-- Modal For update user image -->
<div class="modal fade" id="imageModalPop" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Update User Image</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="/update_userimage/<?php echo e($LoggedUserInfo['id']); ?>"  method="POST" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          <?php echo e(method_field('PUT')); ?>

            <div class="modal-body">
                <div class="form-group">
                    <label>Click here to choose file</label>
                    <input style="cursor: pointer;" type="file" name="user_image" class="form-control">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-warning">Update</button>
            </div>
        </form>
      </div>
    </div>
</div>
<!-- End of Modal for update user image --> 

<!-- Modal For update user details -->
<div class="modal fade" id="detailsModalPop" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Update User Details</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="/update_userdetails/<?php echo e($LoggedUserInfo['id']); ?>"  method="POST" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          <?php echo e(method_field('PUT')); ?>

            <div class="modal-body">
                <div class="row">
                    <div class="col-md-4 pr-1">
                        <div class="form-group">
                            <label for="fullname" class="col-form-label">Full Name</label>
                            <input type="text" class="form-control" id="fullname" name="fullname" placeholder="Full Name" value="<?php echo e($LoggedUserInfo['fullname']); ?>">
                        </div>
                    </div>
                    <div class="col-md-8 pr-1">
                        <div class="form-group">
                            <label for="address" class="col-form-label">Address</label>
                            <input type="text" class="form-control" id="address" name="address" placeholder="Address" value="<?php echo e($LoggedUserInfo['address']); ?>">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 pr-1">
                        <div class="form-group">
                            <label for="position" class="col-form-label">Position</label>
                            <input type="text" class="form-control" id="position" name="position" placeholder="Position" value="<?php echo e($LoggedUserInfo['position']); ?>">
                        </div>
                    </div>
                    <div class="col-md-6 pr-1">
                        <div class="form-group">
                            <label for="age" class="col-form-label">Age</label>
                            <input type="text" class="form-control" id="age" name="age" placeholder="Age" value="<?php echo e($LoggedUserInfo['age']); ?>">
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-success">Update</button>
            </div>
        </form>
      </div>
    </div>
</div>
<!-- End of Modal for update user details --> 
<div class="container-fluid">
<div class="row">
    <div class="col-xl-12 col-md-12 mb-12">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">User Profile</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($LoggedUserInfo['fullname']); ?></div>
                    </div>
                    <div class="col-auto">
                        <div class="h5 mb-0 font-weight-bold text-success">
                            <?php $__currentLoopData = $roles->where('id', $LoggedUserInfo['role_id'] ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($role->role_name); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<br><br>

<div class="row">
    <div class="col-xl-4 col-md-4 mb-5">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <img class="img-fluid px-3 px-sm-4 mt-3 mb-4" style="width: 25rem; border-radius: 100%;" src="/user_images/<?php echo e($LoggedUserInfo['user_image']); ?>" alt="...">
                    </div>
                </div>
                <div class="col-auto">
                    <div class="text-m text-center font-weight-bold text-info text-uppercase mb-1"></div>
                    <div class="text-xs text-center font-weight-bold text-warning text-uppercase mb-1">
                        <?php $__currentLoopData = $roles->where('id', $LoggedUserInfo['role_id'] ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($role->role_name); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-5 col-md-5 mb-5">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                    <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">User ID</div>
                    <div class="text text-success text-uppercase mb-1"><?php echo e($LoggedUserInfo['id']); ?></div>
                    <hr>
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Full Name</div>
                        <div class="text text-success mb-1">
                            <?php if($LoggedUserInfo['fullname'] == null): ?>
                                Your Name goes here
                            <?php else: ?>
                                <?php echo e($LoggedUserInfo['fullname']); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Address</div>
                        <div class="text-m text-success mb-1">
                            <?php if($LoggedUserInfo['address'] == null): ?>
                                Your Address goes here
                            <?php else: ?>
                                <?php echo e($LoggedUserInfo['address']); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Age</div>
                        <div class="text-m text-success mb-1">
                            <?php if($LoggedUserInfo['age'] == null): ?>
                                Your Age goes here
                            <?php else: ?>
                                <?php echo e($LoggedUserInfo['age']); ?> years old
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Position</div>
                        <div class="text-m text-success mb-1">
                            <?php if($LoggedUserInfo['position'] == null): ?>
                                Your Position goes here
                            <?php else: ?>
                                <?php echo e($LoggedUserInfo['position']); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <hr>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-3 mb-3">
        <div class="card border-left-success shadow h-10 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Update Profile Details</div>
                    </div>
                    <div class="col-auto">
                        <button class="btn btn-success" data-toggle="modal" data-target="#detailsModalPop"  style="float: right; margin-left: 10px;">Details</button>
                    </div>
                </div>
            </div>
        </div>
        <br>

        <div class="card border-left-warning shadow h-10 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Update Profile Picture</div>
                    </div>
                    <div class="col-auto">
                        <button class="btn btn-warning" data-toggle="modal" data-target="#imageModalPop"  style="float: right; margin-left: 10px;">Image</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ExamProject\resources\views/user_profile/user_profile.blade.php ENDPATH**/ ?>