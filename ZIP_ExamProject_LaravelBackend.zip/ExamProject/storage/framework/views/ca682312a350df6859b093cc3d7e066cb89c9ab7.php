
<?php $__env->startSection('title'); ?>
    LS | Roles
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Topbar -->
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
        <!-- Sidebar Toggle (Topbar) -->
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>
        <!-- Topbar Navbar -->
        <ul class="navbar-nav ml-auto">
            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
                <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-search fa-fw"></i>
                </a>
                <!-- Dropdown - Messages -->
                <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                    aria-labelledby="searchDropdown">
                    <form class="form-inline mr-auto w-100 navbar-search">
                        <div class="input-group">
                            <input type="text" class="form-control bg-light border-0 small"
                                placeholder="Search for..." aria-label="Search"
                                aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="button">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </li>
            <div class="topbar-divider d-none d-sm-block"></div>
            <li class="nav-item dropdown no-arrow">
                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo e($LoggedUserInfo['fullname']); ?> </span>
                    <img class="img-profile rounded-circle"
                        src="/user_images/<?php echo e($LoggedUserInfo['user_image']); ?>">
                </a>
                <!-- Dropdown - User Information -->
                <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                    aria-labelledby="userDropdown">
                    <a class="dropdown-item" href="/show_userprofile">
                        <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                        Profile
                    </a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                        <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                        Logout
                    </a>
                </div>
            </li>
        </ul>
    </nav>
<!-- End of Topbar -->

<div class="container-fluid">
<div class="row">
    <div class="col-md-5">
        <div class="card card-tasks">
            <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Update Role</h5>
                </div>
                <form action="/role_update_action/<?php echo e($role->id); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?> 
                    <?php echo e(method_field('PUT')); ?>

                <style>
                  .form-control {
                    color: #333;
                  }
                </style>
                <div class="modal-body">
                    <div class="row">
                      <div class="col-md-12 pr-1">
                        <div class="form-group">
                          <label for="role_name" class="col-form-label">Role Name</label>
                          <input type="text" class="form-control" id="role_name" name="role_name" value="<?php echo e($role->role_name); ?>">
                        </div>
                      </div>
                    </div>
                    <div class="mb-3">
                        <label for="message-text" class="col-form-label">Role Description:</label>
                        <textarea class="form-control" id="message-text" name="role_description"><?php echo e($role->role_description); ?></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-success">Update</button>
                </div>
                </form>
              </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>     

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ExamProject\resources\views/roles/role_update.blade.php ENDPATH**/ ?>