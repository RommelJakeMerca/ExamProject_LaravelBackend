
<?php $__env->startSection('title'); ?>
    LS | User Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Topbar -->
<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
    <!-- Sidebar Toggle (Topbar) -->
    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
        <i class="fa fa-bars"></i>
    </button>
    <!-- Topbar Navbar -->
    <ul class="navbar-nav ml-auto">
        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
        <li class="nav-item dropdown no-arrow d-sm-none">
            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
            </a>
            <!-- Dropdown - Messages -->
            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                    <div class="input-group">
                        <input type="text" class="form-control bg-light border-0 small"
                            placeholder="Search for..." aria-label="Search"
                            aria-describedby="basic-addon2">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="button">
                                <i class="fas fa-search fa-sm"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </li>
        <div class="topbar-divider d-none d-sm-block"></div>
        <li class="nav-item dropdown no-arrow">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo e($LoggedUserInfo['fullname']); ?> </span>
                <img class="img-profile rounded-circle"
                    src="/user_images/<?php echo e($LoggedUserInfo['user_image']); ?>">
            </a>
            <!-- Dropdown - User Information -->
            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                aria-labelledby="userDropdown">
                <a class="dropdown-item" href="/show_userprofile">
                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                    Profile
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                    Logout
                </a>
            </div>
        </li>
    </ul>
</nav>
<!-- End of Topbar -->

<!-- Modal for adding new data -->
<div class="modal fade col-md-12" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Update User Roles</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="/update_user_role/<?php echo e($user->id); ?>" method="POST">
        <?php echo e(csrf_field()); ?> 
        <?php echo e(method_field('PUT')); ?>

        <style>
          .form-control {
            color: #333;
          }
        </style>
        <div class="modal-body">
            <div class="row">
                <div class="col-md-12 pr-1">
                  <div class="form-group">
                    <label>Update User Role</label>
                      <select name="role_id" id="role_id" class="form-control" style="appearance: none;">
                        <?php $__currentLoopData = $roles->where('id', $role->id ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($role->id); ?>" disabled selected><?php echo e($role->role_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_roles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($row_roles->id); ?>"><?php echo e($row_roles->role_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                  </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-success">SAVE</button>
        </div>
        </form>
      </div>
    </div>
  </div>

<div class="container-fluid">
<div class="row">
    <div class="col-xl-6 col-md-6 mb-6">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-5">
                        <img class="img-profile rounded-circle" src="/user_images/<?php echo e($user->user_image); ?>">
                    </div>
                    <div class="col-auto" style="margin-right: 30px;">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">User ID</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($user->id); ?></div>
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">User Name</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($user->fullname); ?></div>
                        <br><br>
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">User Email</div>
                        <div class="h5 mb-0 text-gray-800" style="font-size: 1em;"><?php echo e($user->email); ?></div>
                        <br><hr>
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Role ID</div>
                        <div class="h5 mb-0 text-gray-800" style="font-size: 1em;"><?php echo e($role->id); ?></div>
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">User Role</div>
                        <div class="h5 mb-0 text-gray-800" style="font-size: 1em;"><?php echo e($role->role_name); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-3 mb-3">
        <div class="card border-left-warning shadow h-10 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Return</div>
                    </div>
                    <div class="col-auto">
                        <a href="/users/dashboard" class="btn btn-warning" style="float: right; margin-left: 10px;">&larr; Return</a>
                    </div>
                </div>
            </div>
        </div>
        <br>
    
        <div class="card border-left-success shadow h-10 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Role</div>
                    </div>
                    <div class="col-auto">
                        <a data-toggle="modal" data-target="#exampleModal" class="btn btn-success" style="float: right; margin-left: 10px;">Edit</a>
                    </div>
                </div>
            </div>
        </div>
        <br>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ExamProject\resources\views/users/user_details.blade.php ENDPATH**/ ?>