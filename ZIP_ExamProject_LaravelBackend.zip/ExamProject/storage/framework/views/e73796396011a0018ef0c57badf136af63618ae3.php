
<?php $__env->startSection('title'); ?>
    LS | Roles
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Topbar -->
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
        <!-- Sidebar Toggle (Topbar) -->
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>
        <!-- Topbar Navbar -->
        <ul class="navbar-nav ml-auto">
            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
                <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-search fa-fw"></i>
                </a>
                <!-- Dropdown - Messages -->
                <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                    aria-labelledby="searchDropdown">
                    <form class="form-inline mr-auto w-100 navbar-search">
                        <div class="input-group">
                            <input type="text" class="form-control bg-light border-0 small"
                                placeholder="Search for..." aria-label="Search"
                                aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="button">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </li>
            <div class="topbar-divider d-none d-sm-block"></div>
            <li class="nav-item dropdown no-arrow">
                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo e($LoggedUserInfo['fullname']); ?> </span>
                    <img class="img-profile rounded-circle"
                        src="/user_images/<?php echo e($LoggedUserInfo['user_image']); ?>">
                </a>
                <!-- Dropdown - User Information -->
                <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                    aria-labelledby="userDropdown">
                    <a class="dropdown-item" href="/users_profile/user_profile">
                        <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                        Profile
                    </a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                        <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                        Logout
                    </a>
                </div>
            </li>
        </ul>
    </nav>
<!-- End of Topbar -->
<!-- Modal for adding new data -->
<div class="modal fade col-md-12" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Add Role</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="<?php echo e(route('add_role')); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <style>
          .form-control {
            color: #333;
          }
        </style>
        <div class="modal-body">
            <div class="row">
              <div class="col-md-12 pr-1">
                <div class="form-group">
                  <label for="role_name" class="col-form-label">Role Name</label>
                  <input type="text" class="form-control" id="role_name" name="role_name">
                </div>
              </div>
            </div>
            <div class="mb-3">
                <label for="message-text" class="col-form-label">Role Description:</label>
                <textarea class="form-control" id="message-text" name="role_description"></textarea>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-success">SAVE</button>
        </div>
        </form>
      </div>
    </div>
  </div>

<!-- Modal For confirm delete -->
<div class="modal fade" id="deleteModalPop" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Confirm Delete</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <form id="deleteModalForm" method="POST">
          <?php echo e(csrf_field()); ?>

          <?php echo e(method_field('DELETE')); ?>

        <div class="modal-body">
          <div class="form-group">
            <h5>Are you sure you want to delete this role?</h5>
            <input type="hidden" name="id" class="form-control" id="delete_role_id" disabled>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary">Confirm Delete</button>
        </div>
        </form>

      </div>
    </div>
  </div>

<div class="container-fluid">
<div class="row">
    <div class="col-md-12">
      <div class="card card-tasks">
        <div class="card-header ">
          <h5 class="card-category">Roles List</h5>
          <a href="#" class="btn btn-success btn-icon-split float-right" data-toggle="modal" data-target="#exampleModal" >
            <span class="icon text-white-50">
                <i class="fas fa-plus"></i>
            </span>
            <span class="text">Add Role</span>
           </a>
        </div>
        <div class="card-body ">
          <div class="table-full-width table-responsive">
              <style>
                a.disabled {
                    pointer-events: none;
                    cursor: default;
                }
              </style>
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Role Name</th>
                        <th>Role Description</th>
                        <th>Role Users</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text"><?php echo e($row->id); ?></td>
                            <td class="text"><?php echo e($row->role_name); ?></td>
                            <td class="text-left"><?php echo e($row->role_description); ?></td>
                            <td class="text-left"><?php echo e(count($users->where("role_id", "==", $row->id))); ?></td>
                            <?php if($LoggedUserInfo['role_id'] != 1000): ?>
                                <td><a href="/province_update/" class="btn btn-warning disabled">Edit</a></td>
                                <td><a href="javascript:void(0)" class="btn btn-danger deletbtn disabled">Delete</a></td>
                            <?php else: ?>
                                <td><a href="/role_update/<?php echo e($row->id); ?>" class="btn btn-info">Edit</a></td>
                                <td><a href="javascript:void(0)" class="btn btn-danger deletbtn">Delete</a></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>     

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('dashboard_assets/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
    $('#dataTable').DataTable();
    $('#dataTable').on('click', '.deletbtn', function() {
        $tr = $(this).closest('tr');

        var data = $tr.children("td").map(function() {
            return $(this).text();
        }).get(); 

        // console.log(data);

        $('#delete_role_id').val(data[0]);
        $('#deleteModalForm').attr('action', '/delete_role/'+data[0]);
        $('#deleteModalPop').modal('show');
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ExamProject\resources\views/roles/roles.blade.php ENDPATH**/ ?>