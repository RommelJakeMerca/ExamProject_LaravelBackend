<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use App\Models\Users;
use App\Models\Roles;
use Session;
use Illuminate\Support\Facades\Hash;


class MainController extends Controller
{
    // to show login view
    function show_login() {
        return view('authentication.login');
    }

    // to show register view
    function show_register() {
        return view('authentication.register');
    }

    // to register the user
    public function register(Request $request) {
        // Validation
        $errorMsgs = [
            'fullname.required' => 'Name is Required',
            'fullname.max' => 'Max input is 50 characters',
            'email.required' => 'Email is Required',
            'email.unique' => 'Email is already taken',
            'email.email' =>  'Email must be valid',
            'password.required' => 'Password is Required',
            'password.confirmed' => 'Passwords does not match',
        ];
        $this->validate($request, [
            'fullname' => 'required|max:50',
            'email' => 'unique:users|required|email',
            'password' => 'required|min:7|max:12|confirmed',
            'password_confirmation' => 'required|min:7|max:12'
        ], $errorMsgs);

        // insert data to database 
        $user = new Users;
        $user->fullname = $request->input('fullname');
        $user->email = $request->input('email');
        $user->password = Hash::make($request->input('password'));
        $create_user = $user->save();
        if($create_user) {
            Session::flash('statuscode', 'success');
            return redirect('/auth/login')->with(['status' => "Registration Success, You may now login"]);
        }else {
            Session::flash('statuscode', 'error');
            return redirect()->back()->with(['status' => "Registration Failed, Please check your fields"]);
        }
    }

    // to login the user 
    public function login(Request $request) {
        // Validation
        $errorMsgs = [
            'email.email' =>  'Email must be valid',
            'password.required' => 'Password is Required'
        ];
        $this->validate($request, [
            'email' => 'required|email',
            'password' => 'required|min:7|max:12',
        ], $errorMsgs);

            
        // Get User Info
        $userInfo = Users::where('email', '=', $request->input('email'))->first();

        if($userInfo == null){
            Session::flash('statuscode', 'error');
            return redirect()->back()->with(['status' => "Login Failed, we dont recognize your email."]);
        }else {
            // Check Password if match
            if(Hash::check($request->input('password'), $userInfo->password)){
                $request->session()->put('currentUser', $userInfo->id);
                Session::flash('statuscode', 'success');
                return redirect('/users/dashboard')->with(['status' => "Login Success, Welcome"]);
            }else {
                Session::flash('statuscode', 'error');
                return redirect()->back()->with(['status' => "Login Failed, incorrect password."]);
            }
        }
    }
    
    // to logout the user
    public function logout() {
        if(session()->has('currentUser')){
            session()->pull('currentUser');
            Session::flash('statuscode', 'info');
            return redirect('auth/login')->with(['status' => "Logged out, See you!"]);
        }
    }

    // to show users dashboard
    public function show_dashboard(){
        $data = ['LoggedUserInfo'=>Users::where('id', '=', session('currentUser'))->first()];
        $users = Users::all();
        $roles = Roles::all();
        return view('users.dashboard', $data)->with('users', $users)
                                            ->with('roles', $roles);
    }

    // announcement confirm delete
    public function delete_user($id) {
        $user = Users::findOrfail($id);
        $user->delete();
        Session::flash('statuscode', 'error');
        return redirect('/users/dashboard')->with('status', 'User Deleted!');
    }

    // show user details 
    public function user_details($id) {
        $data = ['LoggedUserInfo'=>Users::where('id', '=', session('currentUser'))->first()];
        $user = Users::findOrfail($id);
        $role = Roles::where('id', $user->role_id)->first();
        $roles = Roles::all();
        return view('users.user_details', $data)->with('user', $user)
                                            ->with('role', $role)
                                            ->with('roles', $roles);
    }
    // update user roles
    public function update_user_role(Request $request, $id) {
        $user = Users::findOrfail($id);
        $user->role_id = $request->input('role_id');
        $user->save();
        Session::flash('statuscode', 'info');
        return redirect('/users/dashboard')->with('status', 'User Role Updated!');
    }

    // to show users dashboard
    public function show_userprofile(){
        $data = ['LoggedUserInfo'=>Users::where('id', '=', session('currentUser'))->first()];
        $roles = Roles::all();
        return view('user_profile.user_profile', $data)->with('roles', $roles);
    }

    // to update user image
    public function update_userimage(Request $request, $id){
        $user = Users::findOrfail($id);
        
        if ($request->hasFile('user_image'))  {
            $image = $request->file('user_image');
            $extension = $image->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $image->move('user_images/', $filename);
            $user->user_image = $filename;
        }

        $user->update();
        Session::flash('statuscode', 'info');
        return redirect('users_profile/user_profile')->with('status', 'User Image Updated Successfully!');
    }

    // to update user details
    public function update_userdetails(Request $request, $id){
        $user = Users::findOrfail($id);
        $user->fullname = $request->input('fullname');
        $user->address = $request->input('address');
        $user->position = $request->input('position');
        $user->age = $request->input('age');
        
        $user->update();
        Session::flash('statuscode', 'info');
        return redirect('users_profile/user_profile')->with('status', 'User Details Updated Successfully!');
    }

    // to show roles table
    public function show_roles(){
        $data = ['LoggedUserInfo'=>Users::where('id', '=', session('currentUser'))->first()];
        $users = Users::all();
        $roles = Roles::all();
        return view('roles.roles', $data)->with('roles', $roles)
                                        ->with('users', $users);
    }
    // add role 
    public function add_role(Request $request) {
        $role = new Roles;
        $role->role_name = $request->input('role_name');
        $role->role_description = $request->input('role_description');

        $role->save();
        Session::flash('statuscode', 'info');
        return redirect('roles/roles')->with('status', 'Role Added Successfully!');
    }
    // role confirm delete
    public function delete_role($id) {
        $role = Roles::findOrfail($id);
        $role->delete();
        Session::flash('statuscode', 'error');
        return redirect('roles/roles')->with('status', 'Role Deleted!');
    }
    // to show page for updating role
    public function role_update($id){
        $data = ['LoggedUserInfo'=>Users::where('id', '=', session('currentUser'))->first()];
        $role = Roles::findOrfail($id);
        return view('roles.role_update', $data)->with('role', $role);
    }
    // to update the subcategory
    public function role_update_action(Request $request, $id){
        $role = Roles::findOrfail($id);
        $role->role_name = $request->input('role_name');
        $role->role_description = $request->input('role_description');

        $role->update();
        Session::flash('statuscode', 'info');
        return redirect('roles/roles')->with('status', 'Role Updated Successfully!');
    }

}
