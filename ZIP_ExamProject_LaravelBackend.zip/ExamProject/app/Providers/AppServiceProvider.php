<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\View;
use App\Models\Users;
use Session;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        // if(session()->has('currentUser')){
        //     // // Load your objects
        //     // $data = ['LoggedUserInfo'=>Users::where('id', '=', session('currentUser'))->first()];
        //     dd($data);
        //     // View::share('LoggedUserInfo', $data);
        // }else {
        //     dd('no data');
        // }
        
    }
}
